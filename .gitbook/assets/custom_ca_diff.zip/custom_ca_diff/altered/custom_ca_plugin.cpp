#include "custom_ca_plugin.h"

CustomCAPlugin::CustomCAPlugin()
{
}
